import { RequestHandler } from "express";

interface RegistrationData {
  nickname: string;
  email: string;
  city: string;
}

// In-memory storage for demo purposes
// Replace with actual database for production
const registrations: RegistrationData[] = [];

export const handleRegister: RequestHandler = (req, res) => {
  const { nickname, email, city } = req.body as RegistrationData;

  // Validate input
  if (!nickname || !email || !city) {
    res.status(400).json({ error: "Missing required fields" });
    return;
  }

  // Store registration
  registrations.push({ nickname, email, city });

  // Generate a simple password (in production, use a secure random generator)
  const password = Math.random().toString(36).substring(2, 10).toUpperCase();

  // TODO: Send email with password using SendGrid, Resend, or SMTP
  console.log(`Registration received for ${email}, password would be sent: ${password}`);

  res.json({
    success: true,
    message: "Registration successful. Check your email for the password.",
  });
};
