import { RequestHandler } from "express";

// Store generated passwords in memory
// In production, store in database with expiration
const passwordStore: Map<string, { password: string; createdAt: number }> =
  new Map();

// Default master password for demo (should be configurable from admin)
const MASTER_PASSWORD = process.env.MACHI_PASSWORD || "MACHI";

export const handleVerifyPassword: RequestHandler = (req, res) => {
  const { password } = req.body as { password: string };

  if (!password) {
    res.status(400).json({ valid: false });
    return;
  }

  // Check against master password
  // In production, this should also check against user-specific passwords sent via email
  const isValid = password === MASTER_PASSWORD;

  res.json({ valid: isValid });
};
