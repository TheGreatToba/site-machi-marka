import { useState } from "react";
import { Check } from "lucide-react";

interface RegistrationFormProps {
  onSubmit: (data: {
    nickname: string;
    email: string;
    city: string;
  }) => Promise<void>;
}

export function RegistrationForm({ onSubmit }: RegistrationFormProps) {
  const [nickname, setNickname] = useState("");
  const [email, setEmail] = useState("");
  const [city, setCity] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      await onSubmit({ nickname, email, city });
      setIsSubmitted(true);
      setNickname("");
      setEmail("");
      setCity("");
      setTimeout(() => setIsSubmitted(false), 2000);
    } catch (error) {
      console.error("Registration failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-xs">
      <div className="space-y-6">
        <div>
          <input
            type="text"
            placeholder="NICKNAME"
            value={nickname}
            onChange={(e) => setNickname(e.target.value)}
            required
            className="input-minimal w-full"
            disabled={isLoading}
          />
        </div>

        <div>
          <input
            type="email"
            placeholder="EMAIL ADDRESS"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="input-minimal w-full"
            disabled={isLoading}
          />
        </div>

        <div>
          <input
            type="text"
            placeholder="CITY"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            required
            className="input-minimal w-full"
            disabled={isLoading}
          />
        </div>

        <div className="flex justify-center pt-2">
          <button
            type="submit"
            disabled={isLoading}
            className={`button-minimal transition-all ${
              isSubmitted ? "opacity-50" : ""
            }`}
          >
            {isSubmitted ? (
              <span className="flex items-center gap-2">
                <Check size={16} />
              </span>
            ) : (
              "REGISTER"
            )}
          </button>
        </div>
      </div>
    </form>
  );
}
