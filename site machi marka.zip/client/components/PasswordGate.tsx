import { useState, useRef, useEffect } from "react";

interface PasswordGateProps {
  onSuccess: (password: string) => void;
  onClose: () => void;
}

export function PasswordGate({ onSuccess, onClose }: PasswordGateProps) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();

    const handleEscKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };

    window.addEventListener("keydown", handleEscKey);
    return () => window.removeEventListener("keydown", handleEscKey);
  }, [onClose]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(false);

    try {
      const response = await fetch("/api/verify-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });

      const data = await response.json();

      if (response.ok && data.valid) {
        onSuccess(password);
      } else {
        setError(true);
        setPassword("");
        if (inputRef.current) {
          inputRef.current.classList.add("animate-shake");
          setTimeout(() => {
            inputRef.current?.classList.remove("animate-shake");
          }, 500);
        }
      }
    } catch (error) {
      console.error("Password verification failed:", error);
      setError(true);
      setPassword("");
    } finally {
      setIsLoading(false);
    }
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-95 flex items-center justify-center z-50"
      onClick={handleBackdropClick}
    >
      <div className="w-full max-w-xs px-6">
        <form onSubmit={handleSubmit}>
          <input
            ref={inputRef}
            type="password"
            placeholder="PASSWORD"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            disabled={isLoading}
            className={`input-minimal w-full transition-all ${
              error ? "animate-subtle-glow" : ""
            }`}
          />
        </form>

        <div className="text-center mt-8">
          <button
            onClick={onClose}
            className="text-xs uppercase font-medium tracking-wide opacity-40 hover:opacity-70 transition-opacity"
            style={{ color: "#F5F5DC" }}
          >
            ESC TO CLOSE
          </button>
        </div>
      </div>
    </div>
  );
}
