export function MachiLogo() {
  return (
    <div className="flex items-center justify-center">
      <img
        src="https://cdn.builder.io/api/v1/image/assets%2Fa7aa053c6a0f442db5850d33486648ab%2F77c869032c974008a2d1ec8e11c2c4b7?format=webp&width=800"
        alt="Machi Logo"
        className="w-24 h-auto md:w-32 object-contain"
      />
    </div>
  );
}
