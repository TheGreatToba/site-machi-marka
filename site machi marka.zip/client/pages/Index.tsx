import { useState, useEffect } from "react";
import { MachiLogo } from "@/components/MachiLogo";
import { RegistrationForm } from "@/components/RegistrationForm";
import { PasswordGate } from "@/components/PasswordGate";

export default function Index() {
  const [showPasswordGate, setShowPasswordGate] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const storedAuth = localStorage.getItem("machi-authenticated");
    if (storedAuth === "true") {
      setIsAuthenticated(true);
    }
  }, []);

  const handleRegistration = async (data: {
    nickname: string;
    email: string;
    city: string;
  }) => {
    try {
      const response = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error("Registration failed");
      }
    } catch (error) {
      console.error("Registration error:", error);
      throw error;
    }
  };

  const handlePasswordSuccess = () => {
    localStorage.setItem("machi-authenticated", "true");
    setIsAuthenticated(true);
    setShowPasswordGate(false);
  };

  if (isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="text-center">
          <h1 className="text-2xl md:text-4xl font-bold tracking-tight mb-4" style={{ color: "#F5F5DC" }}>
            WELCOME
          </h1>
          <p className="text-sm md:text-base max-w-md" style={{ color: "#F5F5DC", opacity: 0.7 }}>
            You have been granted access to Machi Marka.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center px-4 py-12">
      <div className="w-full max-w-xs space-y-16 md:space-y-20">
        {/* Logo Section */}
        <div className="flex justify-center">
          <MachiLogo />
        </div>

        {/* Registration Form Section */}
        <div className="flex justify-center">
          <RegistrationForm onSubmit={handleRegistration} />
        </div>

        {/* Enter Website Link Section */}
        <div className="flex justify-center">
          <button
            onClick={() => setShowPasswordGate(true)}
            className="link-minimal"
          >
            ENTER WEBSITE
          </button>
        </div>
      </div>

      {/* Password Gate Modal */}
      {showPasswordGate && (
        <PasswordGate
          onSuccess={handlePasswordSuccess}
          onClose={() => setShowPasswordGate(false)}
        />
      )}
    </div>
  );
}
